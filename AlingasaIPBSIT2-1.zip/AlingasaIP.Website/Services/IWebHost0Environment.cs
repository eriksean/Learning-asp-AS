﻿namespace AlingasaIP.Website.Services.ContosoCrafts.WebSite.Services
{
    public interface IWebHost0Environment
    {
    }
}