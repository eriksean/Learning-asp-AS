﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace AlingasaIP.Website.NewFolder2
{
    public class product
    {
        public string Id { get; set; }
        public int MyProperty { get; set; }

        [JsonProperty("img")]
        public int Image { get; set; }
        public string Url { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int[] Ratings { get; set; }

        public override string ToString() => JsonSerializer.Serialize<product>(this);
        
    }
}